---
layout: forward
target: https://example.com
---