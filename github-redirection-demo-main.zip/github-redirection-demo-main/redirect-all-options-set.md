---
layout: forward
targettitle: Taking you to example.com
target: https://example.com
targetname: Example.com
time: 10
message: This isn't here any more!
---